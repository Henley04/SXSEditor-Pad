/**
 * themeBootstrap — runs before any renderer script.
 *
 * Provides an immediate ACG fallback by injecting the same token
 * defaults into :root via CSS variables, so the first paint matches the
 * final ACG look (no FOUC).
 *
 * When the main process finishes loading the user's settings, it will
 * call themeAPI.applyTheme(), which overrides these defaults.
 */
(function () {
    if (typeof document === 'undefined') return;
    const style = document.createElement('style');
    style.id = 'theme-bootstrap-fallback';
    style.textContent = `
:root {
    --color-blue-50:  #e8f6f8;
    --color-blue-100: #cfeef2;
    --color-blue-200: #a8e0e8;
    --color-blue-300: #6dcdd8;
    --color-blue-400: #3fb8c9;
    --color-blue-500: #2a8e9c;
    --color-blue-600: #227a86;
    --color-blue-700: #1a5f6a;
    --color-blue-800: #134a52;
    --color-blue-900: #0d363e;
    --color-gray-50:  #f8f4e8;
    --color-gray-100: #f2ede0;
    --color-gray-200: #e8e2ce;
    --color-gray-300: #dad4be;
    --color-gray-400: #ccc6aa;
    --color-gray-500: #ada688;
    --color-gray-600: #8a93a2;
    --color-gray-700: #6b7585;
    --color-gray-800: #4a5568;
    --color-gray-900: #2a3441;
    --color-ink-50:  #f2ede0;
    --color-ink-100: #e8e2ce;
    --color-ink-200: #e0dac4;
    --color-ink-300: #dad4be;
    --color-ink-400: #d2ccb8;
    --color-ink-500: #cac3b0;
    --color-ink-600: #c2bba6;
    --color-ink-700: #b8b19c;
    --color-ink-800: #ada688;
    --color-ink-900: #9d9680;
    --color-red-300:  #f09090;
    --color-red-400:  #d96a6a;
    --color-red-500:  #c04848;
    --color-red-600:  #a83838;
    --color-green-300: #90d490;
    --color-green-400: #6db86b;
    --color-green-500: #559955;
    --color-green-600: #448044;
    --color-amber-300: #f2c14e;
    --color-amber-400: #e8a856;
    --color-amber-500: #cc8f3a;
    --color-purple-400: #9a88c9;
    --color-white: #ffffff;
    --color-black: #000000;
    --space-0: 0;
    --space-1: 2px;
    --space-2: 4px;
    --space-3: 6px;
    --space-4: 8px;
    --space-5: 12px;
    --space-6: 16px;
    --space-7: 20px;
    --space-8: 24px;
    --radius-sm: 2px;
    --radius-md: 4px;
    --radius-lg: 8px;
    --radius-xl: 10px;
    --radius-2xl: 12px;
    --radius-full: 9999px;
    --font-xs: 10px;
    --font-sm: 11px;
    --font-base: 12px;
    --font-md: 13px;
    --font-lg: 14px;
    --font-xl: 18px;
    --font-2xl: 20px;
    --motion-fast: 0.15s;
    --motion-base: 0.2s;
    --motion-slow: 0.3s;
    --shadow-sm: 0 1px 3px rgba(42, 52, 65, 0.08);
    --shadow-md: 0 2px 8px rgba(42, 52, 65, 0.10);
    --shadow-lg: 0 4px 16px rgba(42, 52, 65, 0.12);
    --shadow-xl: 0 8px 32px rgba(42, 52, 65, 0.18);
    --bg-app: #ece8da;
    --bg-panel: #faf8f2;
    --bg-elevated: #ffffff;
    --bg-input: #ffffff;
    --bg-overlay: rgba(42, 52, 65, 0.35);
    --bg-toolbar-start: #faf8f2;
    --bg-toolbar-end: #f2ede0;
    --bg-header-start: #faf8f2;
    --bg-header-end: #f2ede0;
    --bg-button: #faf8f2;
    --bg-button-hover: #f2ede0;
    --bg-button-active: #e0dac4;
    --bg-button-primary: #3fb8c9;
    --bg-button-primary-hover: #5cc8d6;
    --bg-button-success: #6db86b;
    --bg-button-success-hover: #90d490;
    --bg-button-danger: #d96a6a;
    --bg-button-danger-hover: #f09090;
    --fg-primary: #2a3441;
    --fg-secondary: #4a5568;
    --fg-muted: #8a93a2;
    --fg-disabled: #b0a88e;
    --fg-on-accent: #ffffff;
    --fg-on-success: #ffffff;
    --fg-on-warning: #2a3441;
    --fg-toolbar-hover: #1a5f6a;
    --fg-bpm: #2a8e9c;
    --fg-time: #2a3441;
    --bg-singer-active: #cfeef2;
    --accent: #3fb8c9;
    --accent-hover: #5cc8d6;
    --accent-pressed: #2a8e9c;
    --accent-soft: rgba(63, 184, 201, 0.12);
    --accent-softer: rgba(63, 184, 201, 0.04);
    --accent-glow: rgba(63, 184, 201, 0.22);
    --accent-glow-strong: rgba(63, 184, 201, 0.32);
    --accent-line: rgba(63, 184, 201, 0.25);
    --accent-line-strong: rgba(63, 184, 201, 0.40);
    --accent-fg: #2a8e9c;
    --success-soft: rgba(109, 184, 107, 0.15);
    --success-glow: rgba(109, 184, 107, 0.30);
    --warning-soft: rgba(242, 193, 78, 0.15);
    --warning-line: rgba(242, 193, 78, 0.25);
    --warning-glow: rgba(242, 193, 78, 0.08);
    --danger-soft: rgba(217, 106, 106, 0.15);
    --danger-glow: rgba(217, 106, 106, 0.30);
    --purple-soft: rgba(154, 136, 201, 0.15);
    --shadow-color: rgba(42, 52, 65, 0.08);
    --shadow-color-mid: rgba(42, 52, 65, 0.12);
    --shadow-color-strong: rgba(42, 52, 65, 0.20);
    --overlay-scrim: rgba(42, 52, 65, 0.35);
    --panel-line: rgba(200, 194, 166, 0.5);
    --ink-soft: rgba(138, 147, 162, 0.30);
    --border-subtle: #e8e2ce;
    --border-default: #e0dac4;
    --border-strong: #ccc6aa;
    --border-accent: #3fb8c9;
    --success: #6db86b;
    --warning: #f2c14e;
    --danger: #d96a6a;
    --info: #3fb8c9;
    --scrollbar-thumb: rgba(200, 194, 166, 0.5);
    --scrollbar-thumb-hover: rgba(173, 166, 136, 0.7);
    --scrollbar-track: transparent;
    --selection-bg: rgba(63, 184, 201, 0.25);
    --focus-ring: 0 0 0 2px rgba(63, 184, 201, 0.35);
    --button-primary-bg: var(--bg-button-primary);
    --button-primary-fg: var(--fg-on-accent);
    --button-primary-hover: var(--bg-button-primary-hover);
    --button-secondary-bg: var(--bg-button);
    --button-secondary-fg: var(--fg-primary);
    --button-secondary-border: #e0dac4;
    --button-disabled-bg: #e8e2ce;
    --button-danger-bg: var(--bg-button-danger);
    --input-bg: var(--bg-input);
    --input-border: #dad4be;
    --input-fg: var(--fg-primary);
    --input-focus-ring: var(--focus-ring);
    --input-placeholder: #ada688;
    --panel-bg: var(--bg-panel);
    --panel-border: #e0dac4;
    --panel-fg: var(--fg-primary);
    --tooltip-bg: #2a3441;
    --tooltip-fg: #ffffff;
    --selection-bg-token: var(--selection-bg);
    --selection-fg: var(--fg-primary);
    --clip-button: polygon(4px 0, 100% 0, 100% calc(100% - 4px), calc(100% - 4px) 100%, 0 100%, 0 4px);
    --clip-panel: polygon(6px 0, 100% 0, 100% calc(100% - 6px), calc(100% - 6px) 100%, 0 100%, 0 6px);
    --clip-badge: polygon(3px 0, 100% 0, 100% calc(100% - 3px), calc(100% - 3px) 100%, 0 100%, 0 3px);
    --deco-accent-bar: 3px;
    --deco-stripe: repeating-linear-gradient(45deg, transparent 0, transparent 3px, rgba(63, 184, 201, 0.06) 3px, rgba(63, 184, 201, 0.06) 4px);
    --toolbar-accent-line: 3px;
}
`;
    // Insert as early as possible (before other stylesheets) to minimize FOUC
    if (document.head) {
        document.head.insertBefore(style, document.head.firstChild);
    } else {
        document.addEventListener('DOMContentLoaded', () => {
            document.head.insertBefore(style, document.head.firstChild);
        });
    }
})();
